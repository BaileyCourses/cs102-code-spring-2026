/**
 * CS-102 Lab 01: Given feet and inches, converts to total inches.
 * @file height.cpp
 * @author
 * @collaborators
 * @date
 */
#include <iostream>

using namespace std;

/**
 *
 * @param feet
 * @return
 */
int get_inches(int feet) {
    return 0; // replace this line
}

// Controls operation of the program.
int main() {
    cout << "Feet: ";
    int feet = 0;
    cin >> feet;

    // add code here to complete the program

    return 0;
}
