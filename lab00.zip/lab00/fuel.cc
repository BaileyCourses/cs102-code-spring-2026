/**
 * CS-102 Lab 01: Given an amount of fuel and a distance traveled,
 *                calculates the average fuel efficiency.
 * @file fuel.cpp
 * @author
 * @collaborators
 * @date
 */

#include <iostream>

using namespace std;

// Controls operation of the program.
int main() {
	// it's all up to you now :)
}
